require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('../src/db');
const vault = require('../src/services/vault');
const { sendMessageWithToken } = require('../src/services/telegram');

const username = process.env.ADMIN_USERNAME;
const password = process.env.ADMIN_PASSWORD;
const fullName = process.env.ADMIN_FULL_NAME || 'DragonX Admin';

if (!username || !password) {
  console.error('Set ADMIN_USERNAME and ADMIN_PASSWORD in environment.');
  process.exit(1);
}

async function finish(error) {
  if (error) throw error;
  console.log(`Admin ${username} is ready.`);
  db.run("INSERT INTO audit_logs(actor_id,action,resource,resource_id,details) VALUES(NULL,'admin.provision','admin',?,?)", [username, JSON.stringify({ source: 'create-admin script' })], async auditError => {
    if (auditError) console.error('Could not write admin provisioning audit:', auditError.message);
    try {
      const settings = await new Promise((resolve, reject) => db.all("SELECT key,value FROM system_settings WHERE key IN ('admin_security_telegram_bot_token','admin_security_telegram_chat_id','admin_security_notifications_enabled')", [], (e, rows) => e ? reject(e) : resolve(Object.fromEntries(rows.map(row => [row.key, row.value])))));
      if (settings.admin_security_notifications_enabled !== 'false' && settings.admin_security_telegram_bot_token && settings.admin_security_telegram_chat_id) {
        await sendMessageWithToken(vault.decrypt(settings.admin_security_telegram_bot_token), settings.admin_security_telegram_chat_id, '🔐 DragonXBlast security\nAdmin disiapkan melalui create-admin: ' + username);
      }
    } catch (notifyError) {
      console.error('Admin security notification skipped:', notifyError.message);
    }
    db.close();
  });
}

db.get('SELECT id,is_superadmin FROM users WHERE username=? COLLATE NOCASE', [username], (lookupError, existing) => {
  if (lookupError) throw lookupError;
  db.get("SELECT id FROM users WHERE role='admin' AND is_superadmin=1 LIMIT 1", [], async (rootError, root) => {
    if (rootError) throw rootError;
    const isSuperAdmin = existing?.is_superadmin === 1 || !root;
    const hash = await bcrypt.hash(password, 12);
    if (existing) {
      db.run('UPDATE users SET full_name=?,password_hash=?,role=\'admin\',status=\'active\',is_superadmin=? WHERE id=?', [fullName, hash, isSuperAdmin ? 1 : 0, existing.id], finish);
    } else {
      db.run('INSERT INTO users(full_name,username,password_hash,role,status,is_superadmin) VALUES(?,?,?,\'admin\',\'active\',?)', [fullName, username, hash, isSuperAdmin ? 1 : 0], finish);
    }
  });
});
