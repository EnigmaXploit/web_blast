const path = require('node:path');
const fs = require('node:fs/promises');
const crypto = require('node:crypto');
const QRCode = require('qrcode');
const devices = new Map();
const pending = new Map();
const cleaning = new Set();
const retiredSockets = new WeakSet();
const reconnectTimers = new Map();
const reconnectAttempts = new Map();
const roundRobin = new Map();
const MAX_DEVICES = 4;
let latestVersionPromise;

async function getLatestWaWebVersion(baileys) {
  if (!latestVersionPromise) latestVersionPromise = (async () => {
    let timer;
    try {
      return await Promise.race([
        baileys.fetchLatestWaWebVersion().then(result => {
          if (!result.isLatest) throw result.error || new Error('WhatsApp Web version lookup failed');
          console.log('Using latest WhatsApp Web version:', result.version.join('.'));
          return result.version;
        }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('WhatsApp Web version lookup timed out')), 20000); })
      ]);
    } catch (error) { console.warn('Using bundled Baileys web version:', error.message); return null; }
    finally { clearTimeout(timer); }
  })();
  return latestVersionPromise;
}
async function warmUpBaileysVersion() { const baileys = await import('baileys'); return getLatestWaWebVersion(baileys); }

function normalizeSlot(deviceId = 1) {
  const slot = Number(deviceId);
  if (!Number.isInteger(slot) || slot < 1 || slot > MAX_DEVICES) throw Error('Nomor perangkat harus 1 sampai 4.');
  return slot;
}
function deviceKey(userId, deviceId = 1) { return String(userId) + ':' + normalizeSlot(deviceId); }
function authDir(userId, deviceId = 1) {
  const slot = normalizeSlot(deviceId);
  const base = process.env.WA_AUTH_DIR || './wa_auth';
  // Keep the original auth path for slot 1 so existing linked devices still restore.
  return path.resolve(base, slot === 1 ? String(userId) : path.join(String(userId), 'device-' + slot));
}
function markerPath(userId,deviceId){return path.join(authDir(userId,deviceId),'.dragonxblast-state.json')}
async function markDisconnected(userId,deviceId){try{await fs.mkdir(authDir(userId,deviceId),{recursive:true});await fs.writeFile(markerPath(userId,deviceId),JSON.stringify({status:'disconnected',disconnectedAt:new Date().toISOString()}))}catch(error){console.warn('WhatsApp disconnect timestamp could not be saved:',error.message)}}
async function clearDisconnectedMarker(userId,deviceId){await fs.rm(markerPath(userId,deviceId),{force:true}).catch(()=>{})}
function getWhatsAppStatus(userId, deviceId = 1) {
  const s = devices.get(deviceKey(userId, deviceId)) || { status: 'disconnected', qr: null, updatedAt: new Date().toISOString() };
  return { deviceId: normalizeSlot(deviceId), status: s.status, retryCount:s.retryCount||0, qr: s.qr || null, pairingCode: s.pairingCode || null, pairingError: s.pairingError || null, lastError: s.lastError || null, lastCode: s.lastCode || null, updatedAt: s.updatedAt, user: s.user || null };
}
function getWorkerWhatsAppStatuses(userId) { return Array.from({ length: MAX_DEVICES }, (_, i) => getWhatsAppStatus(userId, i + 1)); }
function set(key, patch) { const prev = devices.get(key) || {}; devices.set(key, { ...prev, ...patch, updatedAt: new Date().toISOString() }); }
function makeNumericPairingCode() { return String(crypto.randomInt(1, 10)) + Array.from({ length: 7 }, () => crypto.randomInt(0, 10)).join(''); }
function cancelReconnect(key,resetAttempts=false){const timer=reconnectTimers.get(key);if(timer)clearTimeout(timer);reconnectTimers.delete(key);if(resetAttempts)reconnectAttempts.delete(key)}
function scheduleReconnect(userId,deviceId,{immediate=false}={}){
  const key=deviceKey(userId,deviceId);if(cleaning.has(key)||reconnectTimers.has(key))return;
  const attempts=reconnectAttempts.get(key)||0,delay=immediate?0:Math.min(60000,1500*(2**Math.min(attempts,6))),nextAttempt=immediate?attempts:attempts+1;
  if(!immediate)reconnectAttempts.set(key,nextAttempt);
  set(key,{status:'retrying',sock:null,qr:null,pairingCode:null,retryCount:nextAttempt,lastError:immediate?'Pairing diterima. Menyambungkan ulang…':'Koneksi terputus. Mencoba sambung kembali ('+nextAttempt+') dalam '+Math.max(1,Math.ceil(delay/1000))+' detik…'});
  const timer=setTimeout(async()=>{
    reconnectTimers.delete(key);
    if(cleaning.has(key))return;
    const current=devices.get(key);if(current?.sock&&current.status==='connected')return;
    if(!await hasSavedSession(userId,deviceId)){set(key,{status:'disconnected',sock:null,lastError:'Sesi WhatsApp tidak memiliki kredensial tersimpan. Hubungkan ulang dengan QR atau kode pairing.'});return}
    connectWhatsApp(userId,{},deviceId).catch(error=>console.error('WhatsApp reconnect attempt failed for worker '+userId+' device '+deviceId+':',error.message));
  },delay);
  reconnectTimers.set(key,timer);
}

async function connectWhatsApp(userId, profile = {}, deviceId = 1) {
  const slot = normalizeSlot(deviceId), key = deviceKey(userId, slot), current = devices.get(key);
  if (current?.sock&&(current.status === 'connected' || current.status === 'pairing' || current.status === 'connecting')) return getWhatsAppStatus(userId, slot);
  cancelReconnect(key);
  if (pending.has(key)) return pending.get(key);
  const phone = profile.pairingPhone ? String(profile.pairingPhone).replace(/\D/g, '') : '';
  if (phone && (phone.length < 8 || phone.length > 15)) throw Error('Masukkan nomor WhatsApp dengan kode negara, 8–15 digit.');
  let sessionWasRegistered=false;
  const task = (async () => {
    const b = await import('baileys'), make = b.default || b.makeWASocket;
    const { state, saveCreds } = await b.useMultiFileAuthState(authDir(userId, slot));
    sessionWasRegistered=Boolean(state.creds.registered);
    if (phone && state.creds.registered) throw Error('WhatsApp sudah tertaut pada slot ini. Putuskan perangkat dahulu untuk meminta kode baru.');
    // WhatsApp rejects stale web client revisions before it emits the QR event.
    const version = await getLatestWaWebVersion(b);
    const sock = make({ auth: state, printQRInTerminal: false, ...(version ? { version } : {}) });
    let pairingRequested = false, closed = false;
    const connectTimer = setTimeout(() => {
      const active = devices.get(key);
      if (active?.sock !== sock || active.status !== 'connecting') return;
      closed = true;
      const message = 'WhatsApp tidak memberi respons awal dalam 30 detik. Periksa koneksi keluar server lalu coba lagi.';
      set(key, { status: 'disconnected', sock: null, lastCode: 'TIMEOUT', lastError: message, connectTimer: null });
      markDisconnected(userId,slot);
      try { sock.end(new Error(message)); } catch {}
    }, 30000);
    set(key, { status: 'connecting', qr: null, pairingCode: null, pairingError: null, lastError: null, lastCode: null, sock, connectTimer });
    async function handleConnectionUpdate({ connection, qr, lastDisconnect }) {
      if(connection==='close'&&(cleaning.has(key)||retiredSockets.has(sock)||(devices.get(key)?.sock&&devices.get(key).sock!==sock))){clearTimeout(connectTimer);return}
      if (connection || qr) console.log('WhatsApp event worker ' + userId + ' device ' + slot + ': ' + (connection || 'qr') + (qr ? ' (QR ready)' : ''));
      if (qr && !closed) {
        clearTimeout(connectTimer);
        set(key, { status: 'pairing', lastError: null, connectTimer: null });
        if (phone && !state.creds.registered && !pairingRequested) {
          pairingRequested = true;
          let pairingTimer;
          try {
            const pairingCode = await Promise.race([
              sock.requestPairingCode(phone, makeNumericPairingCode()),
              new Promise((_, reject) => { pairingTimer = setTimeout(() => reject(Object.assign(new Error('WhatsApp tidak membalas permintaan kode dalam 20 detik.'), { code: 'PAIRING_TIMEOUT' })), 20000); })
            ]);
            clearTimeout(pairingTimer);
            if (!closed) set(key, { status: 'pairing', pairingCode });
          } catch (error) {
            clearTimeout(pairingTimer);
            const statusCode = error?.output?.statusCode || error?.statusCode || null;
            let detail = error?.message || 'Permintaan kode pairing ditolak.';
            const timedOut = error?.code === 'PAIRING_TIMEOUT';
            if (Number(statusCode) === 401) detail = 'WhatsApp menolak sesi pairing (401). Kredensial percobaan dibersihkan; coba lagi setelah beberapa saat.';
            if (timedOut) detail = 'Permintaan kode pairing melewati batas waktu. Periksa koneksi server lalu coba lagi.';
            if (!closed) set(key, { status: timedOut ? 'disconnected' : 'pairing', pairingError: detail, lastError: detail, lastCode: timedOut ? 'PAIRING_TIMEOUT' : statusCode, sock: timedOut ? null : sock });
            console.error('WhatsApp pairing code failed for worker ' + userId + ' device ' + slot + ' (' + (statusCode || error?.code || 'unknown') + '):', detail);
            if (timedOut) { closed = true; try { sock.end(error); } catch {} }
          }
        }
        try { const qrImage = await QRCode.toDataURL(qr); if (!closed) set(key, { status: 'pairing', qr: qrImage }); }
        catch (error) { if (!closed) set(key, { status: 'disconnected', sock: null, lastError: 'QR gagal dibuat: ' + error.message }); }
      }
      if (connection === 'open') {
        closed = false; clearTimeout(connectTimer);cancelReconnect(key,true);clearDisconnectedMarker(userId,slot);
        set(key, { status: 'connected', qr: null, pairingCode: null, pairingError: null, lastError: null, lastCode: null, connectTimer: null, user: sock.user?.id || null });
      }
      if (connection === 'close') {
        closed = true; clearTimeout(connectTimer);
        const statusCode = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.statusCode || null;
        let lastError = lastDisconnect?.error?.output?.payload?.message || lastDisconnect?.error?.message || 'Koneksi WhatsApp terputus.';
        const restartRequired = Number(statusCode) === 515 && state.creds.registered;
        if (restartRequired) lastError = 'Pairing diterima. Menyambungkan ulang dengan kredensial baru…';
        if (Number(statusCode) === 401) lastError = 'WhatsApp menolak sesi tersimpan (401). Sesi invalid dibersihkan; minta kode pairing baru.';
        set(key, { status: 'disconnected', qr: null, pairingCode: null, pairingError: Number(statusCode) === 401 ? lastError : null, sock: null, connectTimer: null, lastCode: statusCode, lastError });
        await markDisconnected(userId,slot);
        if (restartRequired) {
          // 515 is the normal post-pairing restart. Save the newly issued creds,
          // then let the reconnect scheduler reopen this session immediately.
          await saveCreds().catch(error => console.error('WhatsApp paired credentials save failed:', error.message));
          scheduleReconnect(userId,slot,{immediate:true});
        } else if (Number(statusCode) === 401) {
          cancelReconnect(key,true);
          await fs.rm(authDir(userId, slot), { recursive: true, force: true }).catch(error => console.error('Failed to clear rejected WhatsApp session:', error.message));
        } else if(state.creds.registered) {
          scheduleReconnect(userId,slot);
        }
        const data = lastDisconnect?.error?.data;
        const reason = data && typeof data === 'object' ? (data.reason || data.code || null) : null;
        console.error('WhatsApp closed worker ' + userId + ' device ' + slot + ' (' + (statusCode || 'unknown') + (reason ? '; reason ' + reason : '') + '): ' + lastError);
      }
    }
    // Baileys batches events here so credentials are fully persisted before a
    // following 515 close event starts the replacement socket.
    sock.ev.process(async events => {
      if (events['creds.update']) await saveCreds().catch(error => console.error('WhatsApp credentials save failed for worker ' + userId + ' device ' + slot + ':', error.message));
      if (events['connection.update']) await handleConnectionUpdate(events['connection.update']);
    });
    return getWhatsAppStatus(userId, slot);
  })();
  pending.set(key, task);
  try { return await task; }
  catch (error) { set(key, { status: 'disconnected', sock: null, lastError: error.message }); await markDisconnected(userId,slot); if(sessionWasRegistered)scheduleReconnect(userId,slot); throw error; }
  finally { pending.delete(key); }
}

async function disconnectWhatsApp(userId, deviceId = 1) {
  const slot = normalizeSlot(deviceId), key = deviceKey(userId, slot), entry = devices.get(key);
  cancelReconnect(key,true);
  if(entry?.sock)retiredSockets.add(entry.sock);
  if (entry?.connectTimer) clearTimeout(entry.connectTimer);
  if (entry?.sock) await entry.sock.logout().catch(() => {});
  devices.delete(key); pending.delete(key);
  await fs.rm(authDir(userId, slot), { recursive: true, force: true });
  return getWhatsAppStatus(userId, slot);
}
async function hasSavedSession(userId, deviceId = 1) { try { await fs.access(path.join(authDir(userId, deviceId), 'creds.json')); return true; } catch { return false; } }
async function restoreWhatsAppSessions(profiles = []) {
  let restored = 0;
  for (const profile of profiles) for (let slot = 1; slot <= MAX_DEVICES; slot++) {
    if (!await hasSavedSession(profile.userId, slot)) continue;
    try { await connectWhatsApp(profile.userId, profile, slot); restored++; }
    catch (error) { console.error('WhatsApp session restore failed for worker ' + profile.userId + ' device ' + slot + ':', error.message); }
  }
  return restored;
}
function listWhatsAppDevices() { return Array.from(devices.entries()).map(([key]) => { const [userId, slot] = key.split(':'); return { userId: Number(userId), ...getWhatsAppStatus(userId, Number(slot)) }; }); }
async function inspectWhatsAppStorage(){
  const base=path.resolve(process.env.WA_AUTH_DIR||'./wa_auth');let rootEntries=[];try{rootEntries=await fs.readdir(base,{withFileTypes:true})}catch(error){if(error.code!=='ENOENT')throw error}
  const candidates=new Map();
  for(const workerDir of rootEntries.filter(x=>x.isDirectory()&&/^\d+$/.test(x.name))){const userId=Number(workerDir.name);const direct=path.join(base,workerDir.name);let children=[];try{children=await fs.readdir(direct,{withFileTypes:true})}catch{}const hasDirectAuth=children.some(child=>!/^device-[2-4]$/.test(child.name));if(hasDirectAuth||devices.has(userId+':1'))candidates.set(userId+':1',{userId,deviceId:1,dir:direct});for(const child of children){const m=/^device-([2-4])$/.exec(child.name);if(m&&child.isDirectory())candidates.set(userId+':'+m[1],{userId,deviceId:Number(m[1]),dir:path.join(direct,child.name)})}}
  for(const [key] of devices){const [userId,deviceId]=key.split(':');if(!candidates.has(key))candidates.set(key,{userId:Number(userId),deviceId:Number(deviceId),dir:authDir(userId,Number(deviceId))})}
  async function folderInfo(dir){let size=0,latest=0;const stack=[dir];while(stack.length){const current=stack.pop();let entries;try{entries=await fs.readdir(current,{withFileTypes:true})}catch{continue}for(const entry of entries){const file=path.join(current,entry.name);try{const st=await fs.lstat(file);if(st.isSymbolicLink())continue;if(st.isDirectory())stack.push(file);else{size+=st.size;latest=Math.max(latest,st.mtimeMs)}}catch{}}}return{size,latest}}
  const sessions=[];let totalBytes=0;for(const item of candidates.values()){let stat;try{stat=await fs.stat(item.dir)}catch{stat=null}if(!stat?.isDirectory()&&!devices.has(item.userId+':'+item.deviceId))continue;let creds=null,marker=null;try{creds=JSON.parse(await fs.readFile(path.join(item.dir,'creds.json'),'utf8'))}catch{}try{marker=JSON.parse(await fs.readFile(markerPath(item.userId,item.deviceId),'utf8'))}catch{}const stored=devices.get(item.userId+':'+item.deviceId);const status=stored?.status||(creds?.registered?'disconnected':stat?'disconnected':'disconnected');const info=stat?await folderInfo(item.dir):{size:0,latest:0};totalBytes+=info.size;const disconnectedAt=marker?.disconnectedAt||(status==='disconnected'?stored?.updatedAt||null:null);sessions.push({userId:item.userId,deviceId:item.deviceId,status,registered:Boolean(creds?.registered),sizeBytes:info.size,disconnectedAt,updatedAt:stored?.updatedAt||null,hasFiles:info.size>0})}
  return{totalBytes,sessions,counts:{total:sessions.length,connected:sessions.filter(x=>x.status==='connected').length,disconnected:sessions.filter(x=>x.status==='disconnected'&&x.registered).length,pending:sessions.filter(x=>x.status==='pairing'||x.status==='connecting'||(x.status!=='connected'&&!x.registered)).length}};
}
async function cleanWhatsAppStorage(mode){
  if(mode==='reset-all'){
    await Promise.allSettled(Array.from(pending.values()));
    const snapshot=await inspectWhatsAppStorage();
    const keys=new Set([...devices.keys(),...pending.keys(),...snapshot.sessions.map(x=>x.userId+':'+x.deviceId)]);
    let removed=0;
    for(const key of keys){
      const [userId,deviceId]=key.split(':').map(Number),entry=devices.get(key);
      cancelReconnect(key,true);cleaning.add(key);
      if(entry?.connectTimer)clearTimeout(entry.connectTimer);
      if(entry?.sock){
        retiredSockets.add(entry.sock);
        try{await Promise.race([entry.sock.logout().catch(()=>{}),new Promise(resolve=>setTimeout(resolve,2500))])}catch{}
        try{entry.sock.end(new Error('WhatsApp sessions reset by administrator'))}catch{}
      }
      devices.delete(key);pending.delete(key);removed++;
    }
    roundRobin.clear();
    const base=path.resolve(process.env.WA_AUTH_DIR||'./wa_auth');
    await fs.rm(base,{recursive:true,force:true});await fs.mkdir(base,{recursive:true});
    for(const key of keys)cleaning.delete(key);
    return{removed,mode,storageBytes:0};
  }
  if(!['stale','pending'].includes(mode))throw Error('Mode pembersihan tidak valid.');
  const report=await inspectWhatsAppStorage(),now=Date.now(),cutoff=3*24*60*60*1000;
  const targets=report.sessions.filter(row=>mode==='pending'
    ? ((row.status==='pairing'||row.status==='connecting'||!row.registered)&&row.status!=='connected')
    : (row.status==='disconnected'&&row.registered&&row.disconnectedAt&&(now-new Date(row.disconnectedAt).getTime())>=cutoff));
  let removed=0;
  for(const row of targets){
    const key=row.userId+':'+row.deviceId,entry=devices.get(key);cancelReconnect(key,true);cleaning.add(key);
    if(entry?.connectTimer)clearTimeout(entry.connectTimer);
    if(entry?.sock){retiredSockets.add(entry.sock);try{entry.sock.end(new Error('WhatsApp session cleanup by administrator'))}catch{}}
    devices.delete(key);pending.delete(key);
    await fs.rm(authDir(row.userId,row.deviceId),{recursive:true,force:true});
    cleaning.delete(key);removed++;
  }
  return{removed,mode,storageBytes:(await inspectWhatsAppStorage()).totalBytes};
}
async function sendWhatsAppMessage(userId, phone, payload, deviceId = null) {
  const available=getWorkerWhatsAppStatuses(userId).filter(x=>x.status==='connected').sort((a,b)=>a.deviceId-b.deviceId);
  if(!available.length)throw Error('Belum ada perangkat WhatsApp yang terhubung.');
  let selected;
  if(deviceId!==null){selected=available.find(x=>x.deviceId===Number(deviceId));if(!selected)throw Error('Sesi WhatsApp yang dipilih tidak terhubung.')}
  else{const last=roundRobin.get(String(userId))||0;selected=available.find(x=>x.deviceId>last)||available[0];roundRobin.set(String(userId),selected.deviceId)}
  const entry=devices.get(deviceKey(userId,selected.deviceId));
  const jid=String(phone).replace(/\D/g,'')+'@s.whatsapp.net';
  const {proto,prepareWAMessageMedia}=await import('baileys');
  const bodyText=String(payload.message||'').trim(),footerText=String(payload.caption||'').trim();
  const imageSource=payload.imageUrl?.startsWith('/uploads/campaigns/')?path.resolve(__dirname,'../public',payload.imageUrl.slice(1)):payload.imageUrl;
  const hasCta=Boolean(payload.buttonText&&payload.destinationUrl);
  if(!hasCta){
    const text=[bodyText,footerText].filter(Boolean).join('\n\n');
    if(imageSource){await entry.sock.sendMessage(jid,{image:{url:imageSource},caption:text.slice(0,1024)});if(text.length>1024)await entry.sock.sendMessage(jid,{text:text.slice(1024)})}
    else if(text)await entry.sock.sendMessage(jid,{text});
    return{imageSent:Boolean(imageSource),textSent:Boolean(text),interactive:false};
  }
  if(!/^https:\/\//i.test(payload.destinationUrl))throw Error('URL tombol CTA harus memakai HTTPS.');
  let imageMessage;
  if(imageSource){
    if(typeof entry.sock.waUploadToServer!=='function')throw Error('Mesin WhatsApp belum menyediakan upload media untuk tombol CTA.');
    const prepared=await prepareWAMessageMedia({image:{url:imageSource}},{upload:entry.sock.waUploadToServer,logger:entry.sock.logger,jid});
    imageMessage=prepared.imageMessage;
  }
  const button=proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({name:'cta_url',buttonParamsJson:JSON.stringify({display_text:String(payload.buttonText).trim(),url:payload.destinationUrl,merchant_url:payload.destinationUrl})});
  const interactiveMessage=proto.Message.InteractiveMessage.create({
    header:imageMessage?proto.Message.InteractiveMessage.Header.create({imageMessage,hasMediaAttachment:true}):undefined,
    body:proto.Message.InteractiveMessage.Body.create({text:bodyText||String(payload.buttonText).trim()}),
    footer:footerText?proto.Message.InteractiveMessage.Footer.create({text:footerText}):undefined,
    nativeFlowMessage:proto.Message.InteractiveMessage.NativeFlowMessage.create({buttons:[button],messageParamsJson:'{}',messageVersion:1}),
    contextInfo:proto.ContextInfo.create({mentionedJid:[],groupMentions:[],statusAttributions:[]})
  });
  const sentAt=Math.floor(Date.now()/1000);
  const message=proto.Message.create({
    messageContextInfo:proto.MessageContextInfo.create({deviceListMetadata:{senderTimestamp:String(sentAt)},deviceListMetadataVersion:2}),
    interactiveMessage
  });
  const bizNode={tag:'biz',attrs:{actual_actors:'2',host_storage:'2',privacy_mode_ts:String(sentAt-77980457)},content:[
    {tag:'interactive',attrs:{type:'native_flow',v:'1'},content:[{tag:'native_flow',attrs:{v:'9',name:'mixed'}}]},
    {tag:'quality_control',attrs:{source_type:'third_party'}}
  ]};
  const additionalNodes=jid.endsWith('@g.us')?[bizNode]:[{tag:'bot',attrs:{biz_bot:'1'}},bizNode];
  await entry.sock.relayMessage(jid,message,{messageId:crypto.randomBytes(10).toString('hex').toUpperCase(),additionalNodes});
  return{imageSent:Boolean(imageMessage),textSent:Boolean(bodyText),interactive:true,buttonText:String(payload.buttonText).trim()};
}
module.exports = { connectWhatsApp, getWhatsAppStatus, getWorkerWhatsAppStatuses, disconnectWhatsApp, listWhatsAppDevices, sendWhatsAppMessage, restoreWhatsAppSessions, hasSavedSession, warmUpBaileysVersion, inspectWhatsAppStorage, cleanWhatsAppStorage, MAX_DEVICES };
