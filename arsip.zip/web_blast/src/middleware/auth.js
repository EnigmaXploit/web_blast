const db = require('../db');

function maintenanceActive(callback) {
  db.get("SELECT value FROM system_settings WHERE key='maintenance_mode'", [], (error, row) =>
    callback(error, row?.value === 'true'));
}

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: { code: 'UNAUTHENTICATED', message: 'Masuk diperlukan.' } });
  if (req.session.user.role === 'admin') return requireAdmin(req, res, next);
  maintenanceActive((error, active) => {
    if (error) return next(error);
    if (active) return res.status(503).json({ error: { code: 'MAINTENANCE_MODE', message: 'Website sedang maintenance. Portal pekerja tidak tersedia sementara.' } });
    next();
  });
}

function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== 'admin') {
    return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'Khusus admin.' } });
  }
  db.get('SELECT role,status,is_superadmin FROM users WHERE id=?', [req.session.user.id], (error, row) => {
    if (error) return next(error);
    if (!row || row.role !== 'admin' || row.status !== 'active') {
      return req.session.destroy(() => res.status(403).json({ error: { code: 'ADMIN_DISABLED', message: 'Akun admin tidak aktif. Silakan masuk kembali dengan akun aktif.' } }));
    }
    req.session.user.isSuperAdmin = row.is_superadmin === 1;
    next();
  });
}

function requireSuperAdmin(req, res, next) {
  requireAdmin(req, res, error => {
    if (error) return next(error);
    if (!req.session.user?.isSuperAdmin) {
      return res.status(403).json({ error: { code: 'SUPERADMIN_REQUIRED', message: 'Fitur ini hanya dapat digunakan superadmin.' } });
    }
    next();
  });
}

function requireWorker(req, res, next) {
  if (!req.session.user || req.session.user.role !== 'user') {
    return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'Khusus akun pekerja.' } });
  }
  maintenanceActive((error, active) => {
    if (error) return next(error);
    if (active) return res.status(503).json({ error: { code: 'MAINTENANCE_MODE', message: 'Website sedang maintenance. Portal pekerja tidak tersedia sementara.' } });
    next();
  });
}

module.exports = { requireAuth, requireAdmin, requireSuperAdmin, requireWorker };
