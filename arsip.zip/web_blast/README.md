# DragonXBlast backend

Backend starter Express 5 + Express Handlebars, SQLite (sql.js WASM inline), Baileys dan Telegraf. Frontend prototipe saat ini disajikan melalui template Handlebars dengan aset SPA pada `src/public`.

## Setup lokal

1. Gunakan Node.js 20+.
2. Jalankan `npm install`.
3. Salin `.env.example` menjadi `.env`, lalu isi `SESSION_SECRET` yang acak. Pada development, Cloudflare Turnstile memakai key uji resmi otomatis jika key belum diisi. Untuk production, isi `CLOUDFLARE_TURNSTILE_SITE_KEY`, `CLOUDFLARE_TURNSTILE_SECRET_KEY`, dan `CLOUDFLARE_TURNSTILE_HOSTNAME` dengan key widget domain production; site key dipakai browser dan secret key hanya di server.
4. Isi `TELEGRAM_BOT_TOKEN` dan `TELEGRAM_ADMIN_IDS` (Telegram numeric user ID, pisahkan koma) bila bot dipakai. Admin perlu membuka chat dan mengirim `/start` lebih dahulu agar bot dapat mengirim notifikasi.
5. Jalankan `npm run dev`; buka `http://localhost:3000`.
6. Buat akun admin awal (wajib sebelum login admin) dengan `ADMIN_USERNAME=admin ADMIN_PASSWORD='ganti-dengan-password-kuat' ADMIN_FULL_NAME='DragonX Admin' npm run create-admin`. Script akan membuat akun admin atau mempromosikan akun dengan username tersebut ke role admin.

Login admin tersedia di `#/login-admin`; login pekerja di `#/login`. Login admin mengirim `accountType=admin` dan hanya menerima akun ber-role admin. Sesi saat ini tersimpan di memory store bawaan Express dan terhapus saat restart; gunakan Redis/session store persisten sebelum deploy multi-instance. Form daftar serta login pekerja/admin memakai Cloudflare Turnstile dan tokennya diverifikasi server-side. Tanpa kedua key Turnstile, development memakai pasangan key uji Cloudflare yang selalu lolos; production tetap menolak login jika key nyata belum dikonfigurasi. Jangan commit `.env`, `data/`, atau `wa_auth/`.

## Endpoint awal

- `GET /api/v1/health`
- `POST /api/v1/auth/register` — `{fullName, username, password, referralCode?, captchaToken}` (token Cloudflare Turnstile)
- `POST /api/v1/auth/login` — `{username, password, accountType:'user|admin', captchaToken}` (token Cloudflare Turnstile)
- `POST /api/v1/auth/logout`, `GET /api/v1/me`
- `GET /api/v1/withdrawals`, `POST /api/v1/withdrawals`
- Worker: `GET /api/v1/worker/dashboard`, perangkat WA, rekening/e-wallet, permintaan perubahan akun, kampanye yang ditugaskan admin dan withdraw.
- Admin: overview, pekerja, perangkat WA, review kampanye, laporan, withdraw, permintaan perubahan akun dan pengaturan rate pendapatan.
- Admin WA: `POST /api/v1/admin/wa/connect`, `GET /api/v1/admin/wa/status`, `GET /api/v1/admin/wa/qr`, `DELETE /api/v1/admin/wa/device`
- `POST /integrations/telegram/webhook` (secret header Telegram; set webhook mode variables for registration)

Lihat [API_PLAN.md](./API_PLAN.md) untuk rancangan endpoint lengkap. Impor pool target, antrean delivery provider, dan pencatatan earnings otomatis masih tahap berikutnya.

## Baileys / WhatsApp

Pekerja dapat memulai pairing untuk perangkatnya sendiri; admin dapat memantau perangkat semua pekerja. QR hanya tersedia lewat endpoint yang memerlukan sesi admin/pekerja sesuai kepemilikan dan tidak pernah dikirim ke log atau Telegram. Pengiriman belum diaktifkan dalam starter ini. Baileys adalah adapter WhatsApp Web tidak resmi; evaluasi WhatsApp Business Platform untuk produksi. Implementasikan verifikasi consent, suppression/opt-out, throttling, audit dan kebijakan provider sebelum membuka pengiriman kampanye.

## WhatsApp session cleanup

Admin portal **Pengaturan Sistem** shows registered session count, online/pending counts, and the size of `WA_AUTH_DIR`. Admins can remove unlinked pairing sessions and sessions disconnected for more than three days. Reset all sessions disconnects linked sockets and permanently clears the entire WhatsApp auth folder; it requires Superadmin confirmation. Worker accounts and worker profile data are not removed.

Pairing 515 langsung menyambung ulang setelah kredensial disimpan. Jika sesi tertaut terputus karena gangguan sementara, server mencoba menghubungkan ulang dengan jeda bertahap hingga maksimal 60 detik. Sesi yang ditolak WhatsApp dengan 401 tidak diulang otomatis; perangkat harus dipairing kembali.

## Admin security

The first admin created with `npm run create-admin` is assigned the Superadmin role. On an existing database, the migration prefers `ADMIN_USERNAME`; if that variable is unset, it assigns the earliest admin account. Additional admins can be created from **Admin Security** and are ordinary admins. Balance adjustments, withdrawal processing, and financial settings are Superadmin-only.

Admin login IP, browser, successful/failed attempts, and newly seen devices are recorded in the database. The optional IP whitelist accepts exact IP addresses (one per line; CIDR is not supported). Admin-security alerts use their own bot token and Chat ID in the Admin Security page, separate from the Telegram bot used for withdrawal broadcasts. Keep the database and its backups private because it contains security history.
