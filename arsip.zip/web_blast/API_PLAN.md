# DragonXBlast — Rancangan API

Dokumen ini adalah rancangan backend untuk prototipe DragonXBlast. Prefix API: `/api/v1`. Semua endpoint mengembalikan JSON; waktu menggunakan ISO-8601 UTC. ID resource berupa UUID. Endpoint admin memerlukan role `admin` dan dicatat di audit log.

## Arsitektur yang disarankan

- **API service** (Node.js/TypeScript, Fastify atau Express): autentikasi, validasi, RBAC, CRUD.
- **PostgreSQL**: akun, pool target, kampanye, perangkat, pekerjaan, saldo/ledger, penarikan, laporan, audit.
- **Redis + worker queue**: proses impor file, antrean pesan, retry terbatas, dan pekerjaan terjadwal. Request API tidak mengirim broadcast secara sinkron.
- **Realtime**: SSE `/api/v1/admin/live` untuk ringkasan admin, atau WebSocket jika kelak perlu komunikasi dua arah.
- **Object storage privat**: gambar kampanye dan file impor, dengan URL bertanda tangan dan masa berlaku.
- **WhatsApp adapter**: antarmuka provider terpisah. Baileys dapat ditempatkan sebagai adapter eksperimen; untuk produksi, sediakan adapter resmi WhatsApp Business Platform/Cloud API.
- **Telegram bot admin**: adapter notifikasi dan perintah admin terbatas; Telegram tidak menjadi sumber data utama.

## Autentikasi dan peran

| Peran | Hak utama |
|---|---|
| `user` | Mengelola pool target milik sendiri, membuat kampanye, melihat laporan milik sendiri, mengajukan penarikan, melihat status penarikan |
| `admin` | Semua operasi platform: perangkat, pekerja/user, saldo, penarikan, kampanye, laporan, konfigurasi dan audit |
| `system` | Worker internal; tidak dapat dipakai untuk login pengguna |

Gunakan access token berumur pendek dan refresh token yang dapat dicabut. Password disimpan dengan Argon2id/bcrypt. Username unik, dinormalisasi dan case-insensitive. Hindari menyimpan password akun WhatsApp atau sesi Baileys dalam bentuk plaintext.

## Endpoint pengguna dan sesi

- `POST /auth/register` — `{fullName, username, password, referralCode?}`
- `POST /auth/login` — `{username, password, captchaToken}`
- `POST /auth/refresh` — rotasi refresh token
- `POST /auth/logout` — cabut sesi saat ini
- `GET /me` — profil, role, status akun, saldo yang dapat digunakan
- `PATCH /me` — ubah nama tampilan; perubahan username/password dipisah
- `PATCH /me/username` — `{username, currentPassword}`
- `PATCH /me/password` — `{currentPassword, newPassword}`
- `GET /me/withdrawals` — daftar penarikan milik user
- `POST /me/withdrawals` — `{amount, bankAccountId}`; membuat permintaan `pending`
- `GET /me/campaigns` — hanya kampanye milik user

Captcha produksi harus diverifikasi server-side. Mockup checkbox frontend tidak dianggap verifikasi keamanan.

## Pool target dan impor nomor

- `GET /admin/target-pools` — daftar pool, total target, dan total target yang siap.
- `POST /admin/target-pools` — `{name}`
- `DELETE /admin/target-pools/:id` — hapus pool (beserta relasi target).
- `GET /admin/target-pools/:id/targets` — daftar nomor (maksimal 1.000 per respons).
- `POST /admin/target-pools/:id/targets` — tambah manual: `{phone, name?, consentSource}`.
- `POST /admin/target-pools/:id/imports` — upload `.xlsx`, `.csv`, atau `.txt` hingga 8 MB/20.000 nomor, wajib `consentSource`.
- `DELETE /admin/target-pools/:id/targets/:targetId` — hapus satu target.
- `DELETE /admin/target-pools/:id/targets` — hapus semua target dan wajib konfirmasi nama pool.

Pool target dan nomor hanya dikelola admin; pekerja tidak memiliki endpoint CRUD pool/nomor.

Format nomor dinormalisasi ke E.164. Import hanya menerima header yang diizinkan, membatasi ukuran/baris, memvalidasi MIME dan isi, menghapus formula spreadsheet, mendeteksi duplikat, serta mengarantina nomor yang belum punya bukti izin. Suppression list platform harus menang atas semua pool dan kampanye.

## Kampanye dan pemilihan target

- `GET /admin/campaigns` — daftar kampanye, pool target dan total pekerja yang ditugaskan (admin).
- `GET /worker/blasts` — daftar kampanye yang ditugaskan kepada pekerja yang login.
- `POST /admin/campaigns` — admin membuat dan langsung menugaskan kampanye dengan `{title, message, imageUrl?, caption?, buttonText?, destinationUrl?, poolIds[], workerIds?}`; tanpa `workerIds`, kampanye diberikan kepada semua pekerja aktif.
- `GET /campaigns/:campaignId` — konfigurasi dan progres
- `POST /worker/blasts/:campaignId/start` — worker yang ditugaskan meminta mulai; provider delivery harus aktif.
- `PATCH /admin/campaigns/:campaignId` — status/pengaturan hanya admin.
- Laporan kampanye dan detail target hanya admin.

Tombol URL harus memakai HTTPS dan lolos validasi domain/allowlist kebijakan. Batasi mode pengiriman pada pilihan konfigurasi admin, terapkan kuota, throttling, deduplikasi penerima antar-pool, jam tenang, retry berbatas, dan tombol pause/kill switch. Jangan menyediakan opsi untuk menghindari limit provider.

## Perangkat WhatsApp dan mode pengiriman (admin)

- `GET /admin/devices?status=` — total belum tertaut, menghubungkan, online, offline, perlu login, suspended
- `POST /admin/devices` — daftarkan perangkat; `{label, ownerId?, provider}`
- `POST /admin/devices/:deviceId/pairing` — mulai pairing; respons QR/pairing token sekali pakai dengan TTL singkat
- `GET /admin/devices/:deviceId` — status dan health terakhir
- `POST /admin/devices/:deviceId/disconnect` — putuskan sesi
- `POST /admin/devices/:deviceId/reconnect` — antrekan reconnect dengan cooldown
- `DELETE /admin/devices/:deviceId` — cabut perangkat dan hapus kredensial terenkripsi
- `GET /admin/settings/delivery-mode` — mode dan batas aktif
- `PUT /admin/settings/delivery-mode` — ubah mode/rate policy; audit dan dapat memicu pause kampanye

Status perangkat harus bersumber dari heartbeat worker/provider, bukan hanya dari tampilan dashboard. Kredensial pairing tidak boleh dikirim melalui log, Telegram, atau SSE.

## Manajemen pekerja/user dan keuangan (admin)

- `GET /admin/users?search=&status=&cursor=` — daftar pekerja/user, saldo, status, total kampanye
- `GET /admin/users/:userId` — detail profil, perangkat/nomor terkait, saldo ledger, penarikan
- `PATCH /admin/users/:userId` — ubah nama/status atau metadata aman
- `PATCH /admin/users/:userId/username` — `{username, reason}`; invalidasi sesi lama
- `POST /admin/users/:userId/password-reset` — buat proses reset satu kali; jangan tampilkan password baru di respons/log
- `POST /admin/users/:userId/suspend` dan `POST /admin/users/:userId/unsuspend` — wajib alasan; revoke token dan hentikan pekerjaan aktif jika disuspend
- `DELETE /admin/users/:userId` — soft delete, cek ledger/retensi dan minta konfirmasi; jangan hapus catatan transaksi
- `GET /admin/users/:userId/bank-accounts` — rekening tersamarkan
- `PATCH /admin/users/:userId/bank-accounts/:accountId` — ubah rekening dengan verifikasi dan audit; respons hanya nilai tersamarkan
- `GET /admin/finance/summary` — total saldo user, liability, penarikan pending/approved/rejected/paid
- `GET /admin/ledger?userId=&type=&from=&to=` — ledger append-only
- `POST /admin/users/:userId/ledger-adjustments` — `{amount, reason, idempotencyKey}`; wajib audit dan idealnya persetujuan dua admin untuk nominal besar

Semua perubahan saldo dibuat sebagai entri ledger, bukan overwrite angka saldo tanpa jejak. Penghapusan pekerja/user adalah soft delete agar pelaporan dan audit tetap utuh.

## Penarikan dan konfirmasi

- `GET /admin/withdrawals?status=&cursor=` — antrean semua permintaan penarikan
- `GET /admin/withdrawals/:withdrawalId` — detail, rekening tersamarkan, bukti dan riwayat
- `POST /admin/withdrawals/:withdrawalId/approve` — `{note, idempotencyKey}`
- `POST /admin/withdrawals/:withdrawalId/reject` — `{reason, idempotencyKey}`
- `POST /admin/withdrawals/:withdrawalId/mark-paid` — `{reference, proofAssetId, idempotencyKey}`
- `POST /admin/withdrawals/:withdrawalId/notify-user` — kirim status ke inbox/notifikasi user; opsional kanal eksternal sesuai consent
- `GET /admin/withdrawals/:withdrawalId/events` — audit status

State machine: `pending → approved → paid`, atau `pending → rejected`; transisi final tidak dapat diulang. Penolakan melepaskan saldo tertahan. Pembayaran mencatat referensi transfer dan bukti. Perubahan rekening setelah pengajuan tidak boleh mengubah rekening snapshot pada pengajuan yang sedang berjalan.

### Telegram bot khusus admin

- `POST /integrations/telegram/webhook` — menerima update Telegram; validasi secret header Telegram dan allowlist `chat_id` admin.
- Bot hanya menawarkan perintah berdaftar seperti `/withdrawals`, `/withdrawal <id>`, `/help`; pesan biasa tidak diperlakukan sebagai perintah.
- Persetujuan/penolakan finansial sebaiknya dilakukan di portal admin dengan session MFA. Jika kelak tombol Telegram diizinkan, callback wajib memverifikasi identitas admin, meminta konfirmasi kedua, menerapkan idempotency key, dan menghasilkan audit event yang sama seperti endpoint portal.
- `POST /admin/telegram/test` — kirim pesan uji ke chat admin yang sudah diverifikasi.

Bot dapat mengirim ringkasan/alert penarikan, tetapi jangan mengirim password, token, QR pairing, nomor rekening penuh, atau data sensitif. Broadcast Telegram hanya ke grup/chat admin yang telah di-allowlist; bukan ke pengguna Telegram arbitrer.

## Ringkasan realtime admin

- `GET /admin/overview` — snapshot: total pekerja aktif, target ready/eligible, perangkat terhubung, WA online, antrean, kampanye aktif, total saldo, total penarikan per status.
- `GET /admin/live` — SSE yang mengirim event `system.snapshot`, `device.updated`, `campaign.progress`, `worker.updated`, `withdrawal.updated`, `queue.updated`.
- `GET /admin/reports/campaigns?from=&to=&ownerId=&campaignId=` — laporan agregat kampanye
- `GET /admin/reports/campaigns/:campaignId/recipients?status=&cursor=` — rincian penerima dengan hak akses admin
- `POST /admin/reports/exports` — ekspor laporan CSV/XLSX sebagai job, hasil melalui URL bertanda tangan sementara

Event realtime membawa `eventId`, `occurredAt`, dan ringkasan non-sensitif. Dashboard tetap harus mengambil snapshot REST setelah reconnect agar tidak kehilangan konsistensi.

## Pengaturan identitas sistem (admin)

- `GET /admin/settings/branding` — logo, favicon, nama situs, warna brand/dasbor
- `PATCH /admin/settings/branding` — `{siteName, logoAssetId?, iconAssetId?, colors}`
- `POST /admin/assets` — upload logo/icon/gambar; validasi ukuran, MIME berdasarkan isi, dimensi, dan scan malware
- `GET /public/branding` — konfigurasi brand yang aman untuk halaman publik

Gunakan token warna terbatas/validasi kontras, bukan CSS bebas. Perubahan branding dicatat di audit log dan invalidasi cache.

## Model data inti

`users`, `sessions`, `target_pools`, `targets`, `consent_records`, `suppression_entries`, `imports`, `assets`, `campaigns`, `campaign_targets`, `message_attempts`, `devices`, `device_events`, `withdrawals`, `bank_accounts`, `ledger_entries`, `system_settings`, `audit_logs`, `outbox_events`.

Semua tabel multi-tenant membawa `owner_id` bila relevan. Setiap query user dibatasi owner di server; jangan mengandalkan filter dari frontend. Log menyimpan actor, action, resource, alasan, waktu, request ID, dan perubahan tersamarkan.

## Pola respons dan error

Sukses: `{data, meta?}`. Error: `{error:{code,message,requestId,details?}}`. Gunakan status HTTP semantik: `201` dibuat, `202` job antre, `400` validasi, `401` belum autentikasi, `403` role/owner ditolak, `404` tidak ditemukan, `409` konflik state/idempotency, `422` data tidak dapat diproses, `429` rate limit.

## Urutan implementasi

1. Auth/RBAC, user, audit log, dan skema tenant.
2. Pool target admin, consent/suppression dan impor file.
3. Pembuatan kampanye admin, penugasan worker dan laporan dasar.
4. Device registry/provider adapter dan observabilitas worker.
5. Withdrawals + ledger + approval portal.
6. Admin overview, SSE, laporan ekspor.
7. Telegram admin alerts/webhook dan branding settings.

## Catatan provider dan kepatuhan

Baileys adalah library berbasis WebSocket yang berinteraksi dengan WhatsApp Web dan proyeknya menyatakan bukan afiliasi/dukungan resmi WhatsApp. Karena itu, treat adapter Baileys sebagai eksperimen berisiko putus sesi/perubahan protokol dan jangan menganggap status `sent` sebagai bukti delivery. Untuk penggunaan produksi, evaluasi WhatsApp Business Platform resmi serta kebijakan pesan dan opt-in. Semua target kampanye harus memiliki izin yang relevan, identitas pengirim jelas, dan cara berhenti berlangganan; daftar opt-out harus mencegah pengiriman berikutnya.

Referensi: [Baileys repository](https://github.com/WhiskeySockets/Baileys), [Telegram Bot API](https://core.telegram.org/bots/api), [WhatsApp Business Messaging Policy](https://whatsappbusiness.com/policy/), [Meta: WhatsApp business messaging](https://about.fb.com/news/2025/04/ways-to-manage-your-businesses-chats-on-whatsapp/).
